
package prog_a1;

import java.util.Scanner;

public class Prog_A1 {
    
    static String regUser;
    static String regPass;
    static String regFirstName;
    static String regLastName;
    static String regCell;

    
     //Username: must contain an underscore and atleast 5 characters
    public static boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    
    //Password: 8 characters, 1 capital letter, 1 digit, 1 special characters 
    public static boolean checkPasswordComplexity(String password) {
        boolean hasUpper = false; boolean hasDigit = false; boolean hasSpecial = false;
        
        if (password.length() < 8) return false;
        
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }
    
    //Cellphone: starts with +27 and max 13 digits
    public static boolean checkCellphoneNumber(String cell) {
        return cell.startsWith("+27") && cell.length() <= 13;
    }
    
    //Registration method
    public static String registerUsername(String username, String password, String cell) {
        if (!checkUsername(username)) {
            return "Username must include an underscore (_) and 5 or less characters): ";
        } 
        if (!checkPasswordComplexity(password)) {
            return "Needs atleat 8 chararcters, 1 uppercase letter, 1 number, 1 special characters";
        }
        if (!checkCellphoneNumber(cell)) {
            return "Invalid phone number. Must start with +27 and max 13 characters";
        }else
        return "\n Username successfully captured."
                + "\n Password successfully captured."
                + "\n Phone number successfully captured.";
    }
    
    //Login method 
    public static boolean loginUser(String username, String password) {
        return username.equals(regUser) && password.equals(regPass);
    }
    
    //Login status message
    public static String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + regFirstName + ", " + regLastName + "! It is great to see you again"; 
        } else {
            return "Username or password incorrect. Try again";
        }
    }

    
    public static void main(String[] args) {
       
         Scanner input = new Scanner(System.in);
        
         //Step 1: Registration
        System.out.println("Enter First name: ");
        regFirstName = input.nextLine();
        
        System.out.println("Enter Last name: ");
        regLastName = input.nextLine();
        //Username Check
        System.out.println("Create a Username(Requires an underscore (_) and max 5 characters: ");
        regUser = input.nextLine();
        //Password Check
        System.out.println("Create Password(Requires min 8 charaters, 1 capital letter, 1 number and 1 special character: ");
        regPass = input.nextLine();
        //Cellphone Check
        System.out.println("Enter Cellphone number(Must start with +27): ");
        regCell = input.nextLine();
        
        String regMessage = registerUsername(regUser, regPass, regCell);
        
        System.out.println(regMessage);
            
        System.out.println("\nRegistration correct");
        
        //Step 2 Login
        System.out.println("\nPlease login");
        
        System.out.println("Enter username: ");
        String loginUser = input.nextLine();
        
        System.out.println("Enter password: ");
        String loginPass = input.nextLine();
        
        //Checks if login was successful or not
        boolean loggedIn = loginUser(loginUser, loginPass);
        System.out.println(returnLoginStatus(loggedIn));
        if (loggedIn) {
            System.out.println("Successful login");
        } else {System.out.println("Login failed");}
    }
    
}
//Referencing:

//W3Schools
//W3Schools, 2025. W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com [Accessed 22 Apr. 2025].

//GeeksforGeeks
//GeeksforGeeks, 2025. A Computer Science Portal for Geeks. [online] Available at: https://www.geeksforgeeks.org [Accessed 22 Apr. 2025].

//TutorialsPoint
//TutorialsPoint, 2025. Simply Easy Learning. [online] Available at: https://www.tutorialspoint.com [Accessed 22 Apr. 2025].