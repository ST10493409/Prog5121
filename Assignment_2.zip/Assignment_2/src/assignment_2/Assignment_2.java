
package assignment_2;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;



public class Assignment_2 {
    
    private String messageID;
    private String recipientCell;
    private String messageContent;
    private static int totalMessagesSent = 0;
    
    //Check ID is ten digits
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    //Check if phone number is correct
    public int checkRecipientCell() {
        if (recipientCell.length() <= 10 && recipientCell.startsWith("+")) {
            return 1; // Valid
        } else {
            return 0; // Invalid
        }
    }

    //Creating message hash
    public String createMessageHash() {
        String firstTwo = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        String[] words = messageContent.split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length-1];
        String hash = (firstTwo + ":" + totalMessagesSent + ":" + firstWord + lastWord);
        return hash;
    }
    
    //Message option selection
    public String SentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose an option: [Send / Store / Disregard]");
        String choice = scanner.nextLine().trim().toLowerCase();
        
        //Checking if message is less than 250 chars 
        if (messageContent.length() > 250) {
            return "Please enter a message of less than 50 characters.";
        }

        switch (choice) {
            case "send":
                totalMessagesSent++;
                return "Message sent";
            case "store":
                return "Message stored locally";
            case "disregard":
                return "Message disregarded";
            default:
                return "Invalid option";
        }
    }

   

    
    public static void main(String[] args) {
        Random random = new Random();
        //Welcome Message
        JOptionPane.showMessageDialog(null,"Welcome to QuickChat");
        //Choose what to do
        String option = JOptionPane.showInputDialog("Choose one of the following by its corresponding number: " +
                "\n1. Send Messages" + "\n2. Show recent messages(Coming soon)" + "\n3. Quit");
        int select = Integer.parseInt(option);
    
         
         switch (select){
            case 1:
                JOptionPane.showInputDialog("Type OK to continue");
                break;
            case 2:
                JOptionPane.showMessageDialog(null,"Option coming soon");;
                break;
            case 3:
               JOptionPane.showMessageDialog(null,"Thank you and Goodbye");
                break;
            default: 
               JOptionPane.showMessageDialog(null,"Invalid option");  
               break; 
        }
          String info = "";
          String message = JOptionPane.showInputDialog("Enter the number of messages you would like to enter: ");
          int num = Integer.parseInt(message);
          //Creating and generating profile with messages
          for ( int i = 0; i <= num; i++){
          long ID = 1000000000L + (long)(random.nextDouble() * 9000000000L);
          int number = i;
          String recipient = JOptionPane.showInputDialog("Enter recipient phone number: ");
          String mess = JOptionPane.showInputDialog("Enter message: ");
          String[] words = mess.split("\\s+");
          String firstword = words[0];
          String lastword = words[words.length-1];
          String hash = (ID / 100000000) + ":" + "i" + ":" + firstword + lastword;
          String status = JOptionPane.showInputDialog("Enter what to do wit message(type one of the following out): "
          + "Send message" + "Disregard message" + "Store message to send later");
          JOptionPane.showMessageDialog(null,info +"\n" + "\nMessage number" + number + "\nMessageID: " + ID + "\nMessage Hash: " + hash
          + "\nRecipient: " + recipient + "\nMessage" + mess);
          
          
          }
         
         
     
        
               
    
        
        
    }
    
}

//Referencing 
// Website: Stack Overflow
//Reference:
//Stack Overflow (n.d.) Stack Overflow - Where Developers Learn, Share, & Build Careers. Available at: https://stackoverflow.com (Accessed: 26 May 2025).

//Textbook: Cengage Java Programming, 10th Edition
//Reference:
//Farrell, J. (2019) Java Programming. 10th edn. Boston, MA: Cengage Learning.
